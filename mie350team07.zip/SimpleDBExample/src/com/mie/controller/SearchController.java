package com.mie.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.EventDao;
import com.mie.dao.UserDao;
import com.mie.model.Event;
import com.mie.model.User;
import com.mie.util.DbUtil;

public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/event.jsp";
	private static String LIST_EVENT = "/listEvent.jsp";
	private static String SEARCH_EVENT = "/searchNEvent.jsp";
	private EventDao dao;
	private Connection connection;

	public SearchController() {
		super();
		dao = new EventDao();
		connection = DbUtil.getConnection();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String forward = SEARCH_EVENT;
		String pid = request.getParameter("pid");
		// ArrayList al = null;
		// ArrayList pid_list = new ArrayList();
		// String query = "select * from users where userid='" + pid + "' ";
		//
		// System.out.println("query " + query);
		// st = conn.createStatement();
		// ResultSet rs = st.executeQuery(query);

		List<Event> events = new ArrayList<Event>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement
					.executeQuery("select * from Events where EventId='" + pid
							+ "' ");
			while (rs.next()) {
				Event event = new Event();
				event.setEventId(rs.getInt("EventId"));
				event.setEventName(rs.getString("EventName"));
				events.add(event);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// return users;

		// while (rs.next()) {
		// al = new ArrayList();
		//
		// // out.println(rs.getString(1));
		// // out.println(rs.getString(2));
		// // out.println(rs.getString(3));
		// // out.println(rs.getString(4));
		// al.add(rs.getString(1));
		// al.add(rs.getString(2));
		// al.add(rs.getString(3));
		// al.add(rs.getString(4));
		//
		// System.out.println("al :: " + al);
		// pid_list.add(al);
		// }
		request.setAttribute("piList", events);
		RequestDispatcher view = request
				.getRequestDispatcher("/searchview.jsp");
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        
        String keyword = request.getParameter("keyword");
        
        RequestDispatcher view = request.getRequestDispatcher(SEARCH_EVENT);
        request.setAttribute("keyword", keyword);
        request.setAttribute("events", dao.getEventByKeyword(keyword));
        view.forward(request, response);
    }
}