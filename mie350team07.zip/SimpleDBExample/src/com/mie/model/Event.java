// Prabhat: Similar to User.java; for "Events" database
//Josh: renamed eventid -> eventId
    //added other attributes and getters/setters, did not add location and did not modify toString
    //imported java.util.Date
package com.mie.model;
import java.util.Date;
public class Event {
    private int eventId;
    private String eventName;
    private String eventCategory;
    private String ageGroup;
    private String eventDescription;
    private Date startDate;
    private Date endDate;
    private int minAttendance;
    private int maxAttendance;
    
    
    public int getEventId() {
        return this.eventId;
    }
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    public String getEventName() {
        return eventName;
    }
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    public String getEventCategory() {
        return this.eventCategory;
    }
    
    public void setEventCategory(String eventCategory) {
        this.eventCategory = eventCategory;
    }
    
    public String getAgeGroup() {
        return this.ageGroup;
    }
    
    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }
    
    public String getEventDescription() {
        return this.eventDescription;
    }
    
    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }
    
    public Date getStartDate() {
        return this.startDate;
    }
    
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    
    public Date getEndDate() {
        return this.endDate;    
    }
    
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    
    public int getMinAttendance() {
        return this.minAttendance;
    }
    
    public void setMinAttendance(int minAttendance) {
        this.minAttendance = minAttendance;
    }
    
    public int getMaxAttendance() {
        return this.maxAttendance;
    }
    
    public void setMaxAttendance(int maxAttendance) {
        this.maxAttendance = maxAttendance;
    }
    
    @Override
    public String toString() {
        return "Event [eventId=" + eventId + ", eventName=" + eventName + "]";
    }
}